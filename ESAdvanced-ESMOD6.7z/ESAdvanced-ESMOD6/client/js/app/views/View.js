class View{
    constructor(elemento){
        this._elemento = elemento;
    }

    template(){
        throw new Error('O método template tem que ser implementado');
    }

    update(model){
        this._elemento.innerHTML = this.template(model); /* o InnerHTML é um método que converte uma string, 
            que nesse caso é passada pelo elemento, para HTML puro (caso a string esteja correta p/ html) */
    }
}